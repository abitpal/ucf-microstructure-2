# Texas UCF microstructure pitch

In Overleaf, choose **New Project → Upload Project**, upload the ZIP, and compile
**main.tex** with **pdfLaTeX**. The charts and portraits are bundled in **assets/**.
The project uses Fira Sans where available and falls back to Latin Modern locally.

Slide 24 uses **assets/fee-reaction.png**, a presentation copy made with the
image tool from the photo supplied in chat. A file named **assets/fee-reaction.jpg**
takes precedence if you upload the original file. The two
labels are in the LaTeX source under **\feereaction**. The slide shows a mock
round-trip receipt when neither file is present.

The study results are from **research/mstudy_20261117** in the repository.
The six Texas UCF portraits come from the repository's design-guide assets.
The slide sequence, colors, and use of a single reaction gag follow the design
guide, including its notes on the BTC Dealer Flow reference deck.
